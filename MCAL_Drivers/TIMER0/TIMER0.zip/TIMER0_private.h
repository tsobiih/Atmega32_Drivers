/*
 * TIMER0_private.h
 *
 *  Created on: Oct 11, 2024
 *      Author: elwady
 */

#ifndef TIMER0_PRIVATE_H_
#define TIMER0_PRIVATE_H_



#endif /* TIMER0_PRIVATE_H_ */
